
<html>
    <body>
  
    <center>
        <h1>Welcome to the BANK</h1><br>
        <p>Please Login to the User</p><br>


    <form action ="" method="POST" enctype="multipart/form-data">
        <center >          
<table>
    <tr>
    <td>
        <lable>User name :</label>
        <input type="username" name="username" ><br> <br>
    </td>
</tr>

<tr>
    <td>
        <lable>Password  :</label>
        <input type="password" name="password" > <br>
    </td>
</tr>

       <tr>
           <td>
                  <center>
                           <input type="submit" name="submit" value="Login">
                         <input type="submit" name="registration" value="Signup">
                            </center>
                        </td>
                    </tr>
                    
</center>


</form>
</center>

</body>
</html>