
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
   
<center>
        <h1>Welcome to the BANK</h1><br>
        <p>Please Login to the User</p><br>
    <form action ="" method="POST" enctype="multipart/form-data">
        <center >          
<table>
    <tr>
    <td>
        <lable>User name :</label>
       
    </td>
    <td> <input type="username" name="username" ></td>
</tr>
<tr>
    <td>
        <lable>Password  :</label>
        
    </td>
    <td>
    <input type="password" name="password" >
    </td>
</tr>
       <tr>
           <td>
                  <center>
                          <td><input type="submit" name="submit" value="Login"></td>
                       <tr>
                        <td><center><a href="managerRegistration.php">Register Manager</center>
                        
                        </td>
                       </tr>
                            </center>
                        </td>
                    </tr>
                    
</center>
</form>
</center>
</body>
</html>