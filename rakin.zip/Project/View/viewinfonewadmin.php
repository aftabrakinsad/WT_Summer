<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Admin Information</title>
</head>
<body bgcolor="skyblue">
    <tr>
        <td>
            <a href="../View/adminhomepage.php">GO Back</a>
        </td>
    </tr>
    <center>
        <tr>
            <td>
                <h1>Admins Registration Informations</h1>
            </td>
        </tr>

        <tr>
            <?php include("../Control/viewnewadminregistrations.php"); ?>
        </tr>
    </center>
</body>
</html>