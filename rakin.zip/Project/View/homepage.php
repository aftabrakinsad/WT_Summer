<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - City Bank</title>
</head>

<body background="../Image/bg_img.png">
    <header>
        <center>
        <h1><font color="white">Welcome To City Bank Limited</font></h1>
        <p><font color="white"><strong>Log in as..</strong></font></p>
        <p></p>
        </center>
        <nav>
            <center>
                <a href="../View/adminlogin.php"><font color="white"><strong>Admin</strong></font></a><br><br>
                <a href="../View/managerlogin.php"><font color="white"><strong>Manager</strong></font></a><br><br>
                <a href="../View/employelogin.php"><font color="white"><strong>Employee</strong></font></a><br><br>
                <a href="#"><font color="white"><strong>User</strong></font></a><br><br>
            </center>
        </nav>
    </header>
</body>

</html>